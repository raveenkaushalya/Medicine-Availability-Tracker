package com.example.backend.controller;

import com.example.backend.dto.request.UpdatePharmacyMeRequest;
import com.example.backend.dto.response.ApiResponse;
import com.example.backend.entity.Pharmacy;
import com.example.backend.entity.User;
import com.example.backend.repository.PharmacyRepository;
import com.example.backend.repository.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/pharmacies")
@CrossOrigin(origins = {"http://localhost:3000", "http://localhost:5173"}, allowCredentials = "true")
public class PharmacyMeController {

    private final PharmacyRepository pharmacyRepository;
    private final UserRepository userRepository;

    public PharmacyMeController(PharmacyRepository pharmacyRepository,
                                UserRepository userRepository) {
        this.pharmacyRepository = pharmacyRepository;
        this.userRepository = userRepository;
    }

    private User requireLoggedInUser(HttpServletRequest request) {
        var session = request.getSession(false);
        if (session == null) throw new RuntimeException("Not logged in");

        Integer userId = (Integer) session.getAttribute("USER_ID");
        if (userId == null) throw new RuntimeException("Not logged in");

        return userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
    }

    private Pharmacy requireMyPharmacy(User user) {
        return pharmacyRepository.findByEmail(user.getUsername())
                .orElseThrow(() -> new RuntimeException("Pharmacy not found"));
    }

    // ✅ Load full pharmacy details for dashboard
    @GetMapping("/me")
    public ApiResponse me(HttpServletRequest request) {
        User user = requireLoggedInUser(request);
        Pharmacy pharmacy = requireMyPharmacy(user);
        return new ApiResponse(true, "OK", pharmacy);
    }


    // ✅ Update ONLY editable fields
    @PatchMapping("/me")
    public ApiResponse updateMe(@RequestBody UpdatePharmacyMeRequest req, HttpServletRequest request) {

        var session = request.getSession(false);
        if (session == null) return new ApiResponse(false, "Not logged in", null);

        Integer userId = (Integer) session.getAttribute("USER_ID");
        if (userId == null) return new ApiResponse(false, "Not logged in", null);

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Pharmacy pharmacy = pharmacyRepository.findByEmail(user.getUsername())
                .orElseThrow(() -> new RuntimeException("Pharmacy not found"));

        // ✅ only editable fields
        pharmacy.setContactFullName(req.getContactFullName());
        pharmacy.setContactTitle(req.getContactTitle());
        pharmacy.setContactPhone(req.getContactPhone());
        pharmacy.setPharmacyPhoneNumber(req.getPharmacyPhoneNumber());
        pharmacy.setOpeningHoursJson(req.getOpeningHoursJson());
        pharmacy.setAboutPharmacy(req.getAboutPharmacy());

        pharmacyRepository.save(pharmacy);

        return new ApiResponse(true, "Profile updated", pharmacy);
    }

}
