package com.example.backend.entity;

public enum CatalogStatus {
    ACTIVE,
    ARCHIVED
}
