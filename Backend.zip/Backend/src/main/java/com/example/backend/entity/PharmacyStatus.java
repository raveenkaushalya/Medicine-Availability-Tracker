package com.example.backend.entity;

public enum PharmacyStatus {
    PENDING,
    APPROVED,
    REJECTED
}
