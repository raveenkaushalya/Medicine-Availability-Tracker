
  # Pharmacy Availability Tracker

  This is a code bundle for Pharmacy Availability Tracker. The original project is available at https://www.figma.com/design/PKLUihvTLRIgTpmMoNEzgX/Pharmacy-Availability-Tracker.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  